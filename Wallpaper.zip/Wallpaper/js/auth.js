import { initializeApp } from "firebase/app";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail } from "firebase/auth";

// !!! GANTI DENGAN CONFIG MILIK ANDA SENDIRI DARI FIREBASE CONSOLE !!!
const firebaseConfig = {
    apiKey: "AIzaSyDg3dCe_gNgOhHGNgtfZUorwOr0su9Y_yE",
    authDomain: "asepmo-lite.firebaseapp.com",
    databaseURL: "https://asepmo-lite-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "asepmo-lite",
    storageBucket: "asepmo-lite.firebasestorage.app",
    messagingSenderId: "333018337164",
    appId: "1:333018337164:web:b62539601f50e6ec76d0a9",
    measurementId: "G-2MNMTVZ87N"
};

// Inisialisasi
console.log("Firebase Auth Script berhasil dimuat.");
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Ambil elemen HTML secara presisi
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const btnLogin = document.getElementById("btnLogin");
const btnRegister = document.getElementById("btnRegister");
const btnForgotPassword = document.getElementById("btnForgotPassword");

// Pastikan semua elemen ditemukan di DOM
if (!btnLogin || !btnRegister || !btnForgotPassword) {
    console.error("ID elemen HTML tidak ditemukan. Periksa kembali index.html Anda.");
}

// 1. Logika Masuk / Login
btnLogin.addEventListener("click", async () => {
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    if (!email || !password) {
        alert("Peringatan: Email dan Kata Sandi tidak boleh kosong!");
        return;
    }

    btnLogin.innerText = "Memproses...";
    btnLogin.disabled = true;

    try {
        await signInWithEmailAndPassword(auth, email, password);
        alert("Login Berhasil! Mengalihkan ke dashboard...");
        window.location.href = "dashboard.html";
    } catch (error) {
        console.error(error);
        alert("Gagal Masuk: " + menterjemahkanError(error.code));
    } finally {
        btnLogin.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Masuk Aplikasi';
        btnLogin.disabled = false;
    }
});

// 2. Logika Daftar / Registrasi
btnRegister.addEventListener("click", async () => {
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    if (!email || !password) {
        alert("Peringatan: Isi email dan kata sandi terlebih dahulu!");
        return;
    }

    btnRegister.innerText = "Mendaftarkan...";
    btnRegister.disabled = true;

    try {
        await createUserWithEmailAndPassword(auth, email, password);
        alert("Akun sukses dibuat! Anda kini bisa klik tombol 'Masuk Aplikasi'.");
    } catch (error) {
        console.error(error);
        alert("Gagal Mendaftar: " + menterjemahkanError(error.code));
    } finally {
        btnRegister.innerHTML = '<i class="fa-solid fa-user-plus"></i> Daftar Akun Baru';
        btnRegister.disabled = false;
    }
});

// 3. Logika Lupa Kata Sandi
btnForgotPassword.addEventListener("click", async () => {
    const email = emailInput.value.trim();

    if (!email) {
        alert("Silakan ketik alamat email Anda di kolom input terlebih dahulu.");
        return;
    }

    try {
        await sendPasswordResetEmail(auth, email);
        alert("Sukses! Link setel ulang kata sandi telah dikirim ke email " + email);
    } catch (error) {
        console.error(error);
        alert("Gagal Mengirim Email: " + menterjemahkanError(error.code));
    }
});

// Fungsi pembantu untuk menerjemahkan kode error Firebase ke Bahasa Indonesia
function menterjemahkanError(errorCode) {
    switch (errorCode) {
        case "auth/invalid-email": return "Format alamat email tidak valid.";
        case "auth/user-disabled": return "Akun ini telah dinonaktifkan.";
        case "auth/user-not-found": return "Pengguna tidak ditemukan. Silakan daftar akun baru.";
        case "auth/wrong-password": return "Kata sandi salah. Silakan coba lagi.";
        case "auth/email-already-in-use": return "Alamat email ini sudah terdaftar.";
        case "auth/weak-password": return "Kata sandi terlalu lemah (minimal 6 karakter).";
        case "auth/missing-password": return "Kata sandi wajib diisi.";
        default: return errorCode || "Terjadi kesalahan jaringan atau sistem.";
    }
}

